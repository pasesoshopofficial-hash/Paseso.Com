const functions = require("firebase-functions");
const admin = require("firebase-admin");

// Initialize Firebase Admin SDK
admin.initializeApp();

// Database reference
const db = admin.firestore();

// Function to automatically update user post count when a new post is created
exports.updateUserPostCount = functions.firestore
  .document("posts/{postId}")
  .onCreate(async (snap, context) => {
    try {
      // Get the post data
      const post = snap.data();
      const userId = post.userId;
      
      // Reference to the user document
      const userRef = db.collection("users").doc(userId);
      
      // Increment the user's post count
      await userRef.update({
        posts: admin.firestore.FieldValue.increment(1)
      });
      
      console.log(`Updated post count for user ${userId}`);
      return null;
    } catch (error) {
      console.error("Error updating user post count:", error);
      return null;
    }
  });

// Function to automatically update user stats when a post is liked
exports.updateLikeCount = functions.firestore
  .document("likes/{likeId}")
  .onCreate(async (snap, context) => {
    try {
      // Get the like data
      const like = snap.data();
      const postId = like.postId;
      
      // Reference to the post document
      const postRef = db.collection("posts").doc(postId);
      
      // Increment the post's like count
      await postRef.update({
        likes: admin.firestore.FieldValue.increment(1)
      });
      
      console.log(`Updated like count for post ${postId}`);
      return null;
    } catch (error) {
      console.error("Error updating like count:", error);
      return null;
    }
  });

// Function to send notification when a user receives a new message
exports.sendNewMessageNotification = functions.firestore
  .document("messages/{messageId}")
  .onCreate(async (snap, context) => {
    try {
      // Get the message data
      const message = snap.data();
      const recipientId = message.recipientId;
      
      // Get recipient's notification token (if exists)
      const recipientRef = db.collection("users").doc(recipientId);
      const recipientDoc = await recipientRef.get();
      
      if (!recipientDoc.exists) {
        console.log("Recipient does not exist");
        return null;
      }
      
      // Create a notification record
      const notificationData = {
        userId: recipientId,
        title: "New Message",
        body: `You have a new message from ${message.senderName}`,
        type: "message",
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        read: false
      };
      
      // Add notification to Firestore
      await db.collection("notifications").add(notificationData);
      
      console.log(`Sent notification to user ${recipientId}`);
      return null;
    } catch (error) {
      console.error("Error sending message notification:", error);
      return null;
    }
  });

// Function to send notification when a user is tagged in a post
exports.sendTaggedNotification = functions.firestore
  .document("posts/{postId}")
  .onCreate(async (snap, context) => {
    try {
      // Get the post data
      const post = snap.data();
      const content = post.content;
      
      // Extract tagged users (looking for @username pattern)
      const taggedUsernames = content.match(/@(\w+)/g);
      
      if (!taggedUsernames || taggedUsernames.length === 0) {
        return null;
      }
      
      // Process each tagged user
      for (const taggedUsername of taggedUsernames) {
        const username = taggedUsername.substring(1); // Remove @ symbol
        
        // Find user by username
        const userQuery = await db.collection("users")
          .where("username", "==", username)
          .limit(1)
          .get();
          
        if (!userQuery.empty) {
          const userDoc = userQuery.docs[0];
          const userId = userDoc.id;
          
          // Create a notification record
          const notificationData = {
            userId: userId,
            title: "You Were Tagged",
            body: `${post.authorName} tagged you in a post`,
            type: "tag",
            postId: context.params.postId,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            read: false
          };
          
          // Add notification to Firestore
          await db.collection("notifications").add(notificationData);
          
          console.log(`Sent tag notification to user ${userId}`);
        }
      }
      
      return null;
    } catch (error) {
      console.error("Error sending tagged notification:", error);
      return null;
    }
  });

// Function to clean up user data when account is deleted
exports.cleanupUserData = functions.auth.user().onDelete(async (user) => {
  const userId = user.uid;
  
  try {
    // Delete user document
    await db.collection("users").doc(userId).delete();
    
    // Delete user posts
    const postsSnapshot = await db.collection("posts")
      .where("userId", "==", userId)
      .get();
      
    const batch = db.batch();
    postsSnapshot.forEach((doc) => {
      batch.delete(doc.ref);
    });
    
    await batch.commit();
    
    console.log(`Cleaned up data for deleted user ${userId}`);
    return null;
  } catch (error) {
    console.error("Error cleaning up user data:", error);
    return null;
  }
});